import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Portfolio App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const PortfolioPage(),
    );
  }
}

class PortfolioPage extends StatefulWidget {
  const PortfolioPage({super.key});

  @override
  State<PortfolioPage> createState() => _PortfolioPageState();
}

class _PortfolioPageState extends State<PortfolioPage> {
  String _name = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab Task -_-'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Text Field to enter name
            TextField(
              onChanged: (value) {
                setState(() {
                  _name = value;
                });
              },
              style: const TextStyle(fontSize: 18),
              decoration: const InputDecoration.collapsed(
                hintText: 'Enter your name here...',
              ),
            ),
            const SizedBox(height: 20),

            // Dynamic Welcome Message
            if (_name.isNotEmpty)
              Text(
                'Welcome to my page, $_name!',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: Colors.blueAccent,
                ),
              ),
            const SizedBox(height: 30),

            // Images Layout
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/image2.jpg',
                  width: 150,
                  height: 150,
                  fit: BoxFit.cover,
                ),
                const SizedBox(width: 10),
                Image.asset(
                  'assets/image2.jpg',
                  width: 150,
                  height: 150,
                  fit: BoxFit.cover,
                ),
              ],
            ),
            const SizedBox(height: 16),
            Image.asset(
              'assets/image2.jpg',
              width: 250,
              height: 200,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 30),

            // Buttons
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const UniversityPage()),
                );
              },
              child: const Text('My University'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PetKitmiPage()),
                );
              },
              child: const Text('My Pet Kitmi'),
            ),
          ],
        ),
      ),
    );
  }
}

class UniversityPage extends StatefulWidget {
  const UniversityPage({super.key});

  @override
  _UniversityPageState createState() => _UniversityPageState();
}

class _UniversityPageState extends State<UniversityPage> {
  double _sliderValue = 25.0;

  double _calculatePercentage() {
    return ((_sliderValue - (-75)) / (275 - (-75))) * 100;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daffodil International University'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Slider Value Display
            Text(
              'Slider Value: ${_sliderValue.toStringAsFixed(1)}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),

            // Slider
            Slider(
              value: _sliderValue,
              min: -75,
              max: 275,
              divisions: ((275 + 75) ~/ 25),
              label: _sliderValue.toStringAsFixed(1),
              onChanged: (double value) {
                setState(() {
                  _sliderValue = value;
                });
              },
            ),
            const SizedBox(height: 16),

            // Image
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  'assets/university.jpg',
                  width: 300,
                  height: 200,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PetKitmiPage extends StatefulWidget {
  const PetKitmiPage({super.key});

  @override
  _PetKitmiPageState createState() => _PetKitmiPageState();
}

class _PetKitmiPageState extends State<PetKitmiPage> {
  List<String> funFacts = [
    'Loves chasing laser pointers and playing with balls.',
    'Enjoys napping in sunny spots around the house.',
  ];

  final TextEditingController _factController = TextEditingController();

  void _addFunFact() {
    String newFact = _factController.text.trim();
    if (newFact.isNotEmpty) {
      setState(() {
        funFacts.add(newFact);
        _factController.clear();
      });
    }
  }

  void _deleteFunFact(int index) {
    setState(() {
      funFacts.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Pet Kitmi')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Input Field
            TextField(
              controller: _factController,
              decoration: const InputDecoration(
                labelText: 'Enter a fun fact',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),

            // Add Button
            ElevatedButton(
              onPressed: _addFunFact,
              child: const Text('Add Fun Fact'),
            ),
            const SizedBox(height: 20),

            // Fun Facts List
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: funFacts.length,
              itemBuilder: (context, index) => Card(
                child: ListTile(
                  title: Text(funFacts[index]),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _deleteFunFact(index),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Kitmi's Image
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  'assets/kitmi.jpg',
                  width: 250,
                  height: 250,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
